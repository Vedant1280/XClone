package com.example.xclone.data

data class Tweet(
    val tweetContent : String,
    val profileImage : String,
    val accountUserName:String

)