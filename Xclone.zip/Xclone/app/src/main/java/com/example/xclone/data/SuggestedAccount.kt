package com.example.xclone.data

data class SuggestedAccount (
    val profileImage:String,
    val userName:String,
    val uid:String
)

